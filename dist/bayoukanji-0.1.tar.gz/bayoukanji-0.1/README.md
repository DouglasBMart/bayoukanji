# bayoukanji
config for project bayou
